# Mapster

A cross-platform visual data-mapping tool built with [Tauri](https://tauri.app), Rust and React: an
independent alternative to Altova MapForce. Draw lines between the nodes of a source and a target
structure, insert functions, filters and lookups, and run the mapping to produce XML, JSON, CSV,
fixed-length or free-form text, EDI or Excel workbooks.
Mapster also opens MapForce `.mfd` mapping designs directly.

![icon](src-tauri/icons/128x128.png)

## Features

- **Structures**: XML (from XML Schema or inferred from an instance), JSON (from JSON Schema or an
  instance), CSV (header row or positional fields), fixed-length text (field widths and fill
  character), FlexText (MapForce `.mft` templates that split free-form text into fragments by
  lines, separators, regular expressions and switch conditions, store them as values, CSV or
  fixed-length records, and write the same layout back), and EDI: ANSI X12 (including HIPAA),
  UN/EDIFACT (including IATA), HL7 v2 (separators from the MSH segment, sub-components, escape
  sequences, multi-message files selected by MSH-9), TRADACOMS and SAP IDocs (from an SAP parser
  file), read and written with envelope auto-completion (ISA/GS/ST/SE/GE/IEA,
  UNA/UNB/UNH/UNT/UNZ, counts and control numbers) and the parser results MapForce uses for 997/999
  acknowledgments. Excel 2007+ workbooks (`.xlsx`) are laid out like MapForce lays them out:
  worksheets by name (or all of them), row ranges that start at a row or after the previous range,
  hold a fixed or dynamic number of rows and may begin with a header row, and cells as typed columns
  or as one item per cell with its column number; dates, times and numbers become typed cells.
  Any structure can be a source, a target, or an intermediate step of a chained mapping.
- **Visual editor**: schema trees with expandable nodes, drag-to-connect, function library with
  search and drag & drop, component settings, undo/redo, output preview, messages pane, and
  MapForce's context menus: right-click the canvas (insert input/output/constant, cut/copy/paste,
  function settings), a component (change root, refresh, find, align tree, create mapping to XML
  or to an X12 997/999 acknowledgment, priority context, inline a user-defined function call), a
  connection (connect matching children, go to source/target, connection type, insert
  sort/filter/value-map) or a structure node (duplicate inputs before/after, move up/down, delete
  connections, create variables, compute once). As in MapForce, a connection's end can be dragged
  to another node (Ctrl+drag copies it; the connections below it can come along), connecting to an
  input that already has one offers to replace it or duplicate the input, hovering a connection
  names both ends, components snap into line with each other while dragged, and the toolbar can
  dim every connection except the selected components' (optionally traced from source to target).
  Selecting a component colours its connections, followed through functions to their sources and
  targets.
- **Mapster view** (toolbar toggle) for busy mappings: connected constants are shown as values at
  the ports they feed (click to edit, × to disconnect) instead of as components, and the canvas is
  laid out in columns: sources and parameters on the left, functions in between level with the
  ports they feed, targets on the right. It changes only what is drawn; the mapping keeps its
  MapForce layout, which the standard view shows.
- **Transformations**: ~150 built-in functions (string, math, logical, conversion, date/time
  pictures, sequence, aggregates with parent context, grouping, file paths, null handling), constants,
  input parameters, filters (on-true/on-false), if-else chains, value-maps, multi-key sort,
  priority context, copy-all connections and user-defined functions (created and edited in
  their own tabs; call sites follow parameter and result changes automatically).
- **MapForce compatibility**: imports `.mfd` (XML, JSON, CSV, fixed-length, FlexText, X12, EDIFACT, HL7,
  TRADACOMS, IDoc and Excel 2007+ components, "parse string" components, mixed-content text, functions, filters,
  if-else, value-maps, sort, constants, parameters, user-defined functions, priority context, copy-all,
  duplicate inputs, simple and structured variables with compute-when, and joins). The engine
  reproduces MapForce's execution semantics; `tests/conformance` holds mappings together with the
  output that MapForce itself produced for them, and Mapster must match each one. MapForce's own
  example mappings are compared the same way when a copy of them is present (`re/samples/mfx`,
  see `crates/mapster-core/tests/examples.rs`).
- **Mapping assistance**: ✨ Auto-map (fuzzy, synonym-aware name matching that respects the
  structure hierarchy), auto-connect matching children when two parent nodes are connected,
  Validate (dangling ports, unconnected required inputs and target nodes), live output preview,
  sample values from the input file shown on every source node, and automatic reload when the
  open mapping changes on disk (e.g. edited by Claude through the MCP server).
- **AI assist** (*AI* toolbar button, *AI* menu, `Ctrl+Shift+A`): ask Claude to change or explain
  the mapping, and have it fix problems Validate or a run reports. It uses your own Claude Code or
  Codex sign-in, edits a copy of the mapping with Mapster's own tools, and you apply what it
  changed (see [AI assist](#ai-assist)).
- **Code generation**: XSLT 1.0, 2.0 and 3.0 stylesheets (toolbar XSLT button, File menu, or
  `mapster-cli xslt --version 1|2|3`). 1.0 and 2.0 cover XML sources and targets; 3.0 also reads
  JSON sources (`json-to-xml`) and writes JSON targets (`xml-to-json`). Generated stylesheets are
  tested with .NET (XSLT 1.0) and SaxonJS (XSLT 2.0 and 3.0) against the MapForce reference outputs.
- **Opening files**: Open… (Ctrl+O) reads `.mmap` and MapForce `.mfd`; installed bundles register
  both extensions, so double-clicking a `.mfd` opens it in Mapster.
- **Headless runs**: `mapster-cli run mapping.mfd` executes a mapping without the UI.

EDI structures come from MapForce's EDI configuration files, which are not redistributed: they are
read from a MapForce installation (`C:\Program Files\Altova\MapForce20xx\MapForceEDI`), from
`~/.mapster/edi` (copy the MapForceEDI folder there on macOS and Linux), from the folders in
`MAPSTER_EDI_CONFIG`, or next to the mapping. FlexText templates (`.mft`) and SAP IDoc parser
files belong to the mapping and are read next to it; a FlexText source without an input file reads
the sample file its template names. Templates are made and changed in the FlexText designer
(File ▸ New/Open FlexText Template…, a FlexText component's Edit FlexText Template…, or Edit… in
its settings), which shows the fragment of the sample text each container receives as you edit and
saves `.mft` files in MapForce's layout.

MapForce designs import with generic nodes (`element()`, dynamic node and JSON member names), mixed
content, user-defined functions with structured (XML) parameters and results, recursive functions,
node functions and defaults ("rules"), and designs from old MapForce versions.

Functions from libraries are imported with the design: user-defined functions of other `.mfd`
files and named templates of XSLT stylesheets, which run in the engine and become
`xsl:call-template` (with an `xsl:include` of the stylesheet) in generated XSLT. Libraries the design
imports itself (`settings/libraries`) come first; MapForce's global libraries are an application
setting, so the files of a MapForce project (`.mfp`) listing the design, then the other designs and
stylesheets in its folder, stand in for them (the import warnings name each library found that way).
Functions are matched by library and name, so libraries may define functions of the same name.

Excel targets are written as new workbooks holding data only (like MapForce's "overwrite existing
file"); MapForce's "update existing file" option is kept but also writes a new workbook. Named ranges
and tables are not read. The output preview shows a workbook as MapForce's XML view of it
(`Workbook/Worksheet/Row/Cell`); "Save output…" writes the `.xlsx`.

REST web service calls (Insert ▸ Web Service Call (REST)…, or MapForce's web service component
imported from a design) send their request with the mapped URL, parameters, headers and JSON or XML
body, and read the status, headers and the response body chosen by status. Request and response
bodies take their structure from an XML Schema or JSON Schema, or from a sample document. A call
is made either for every input, like an inline function (once per item connected to `Request`,
else wherever its response is read), or once per run, with every connection reading the same
response (a login, a token, a lookup list). Requests can be authenticated with HTTP Basic, a
custom header or API key (as a header or query parameter), or OAuth 2.0 (client credentials,
password and refresh-token grants, or an access token you already have); OAuth tokens are reused
until they expire and renewed after a 401. Any authentication field may hold `${NAME}`, read when
the mapping runs from the input parameter or environment variable of that name, so secrets need
not be saved in the mapping. Calls are made only when the mapping is run (Run, or
`mapster-cli run`); Live preview does not send requests.

Databases (SQLite, PostgreSQL and SQL Server) come in two kinds of component. Insert ▸ Database
Tables… connects to a database and shows the tables you choose, read from its catalogue with their
column types and keys. Connected from, a table is read row by row, with an optional `WHERE`
condition and `ORDER BY`; connected to, every row written becomes an insert, update, merge (update
the row with the same keys, else insert it) or delete, keyed by the primary key or the columns you
name, optionally after deleting every row. Insert ▸ Database Call… runs a query or statement with
`:name` parameters, a function (scalar or table-valued) or a stored procedure. Its parameters,
read from the SQL or the routine's declaration, are the inputs under `Parameters` (unless given a
fixed value), and its outputs under `Result` follow the established result columns:
`ResultSet/Row/<column>` (`ResultSet2`, … for further result sets), a procedure's `Output/<name>`
parameters and SQL Server `ReturnValue`, and a statement's `RowsAffected`. Result columns the
database cannot describe beforehand are read by running the call once inside a transaction that is
rolled back. Like web services, a call runs for every input or once per run. Connection strings
may hold `${NAME}`. Each database gets one connection and one transaction per run, committed only
when the whole run succeeds; previews read tables and run queries and functions but never change
the database (statements and procedures are left out, and table targets show the SQL they would
run). SQL Server needs SQL authentication (Windows integrated authentication is not supported).
MapForce database components import with their data source: tables become a database component
(columns as shown in the design, written with Insert All), and SQL SELECT statements, stored
procedures and functions become database calls. Passwords are not imported: each connection reads
its password from `${<DATA SOURCE>_PASSWORD}` (for example `SYNAPSEEDI_PASSWORD`). Oracle data
sources import but cannot be connected to yet.

Decision tables (Insert ▸ Decision Table…, or MapForce's decision table) try their rules from the
top and give the outputs of the first rule whose conditions all hold. A condition is `-`
(anything), a value, a comparison (`<10`, `>=A`, `!=X`), a range (`1..5`) or several of these
separated by commas; values compare as numbers when both are numbers, and equality is exact, so
`006` does not match `6`.

The file line of a document is its file name port (MapForce's `File:` node). Connected from a
source, it gives the name of the file read; connected to a target, every item names a file of its
own, written with that item as the context of the structure below (dynamic output file names).

Not yet supported: derived-type (`xsi:type`) selection, `xsi:nil` and CDATA output, wildcard and
dynamic input file names, JSON Lines, Oracle and other database engines, MapForce table actions
other than Insert All, SWIFT MT and other fixed-length EDI, Excel
97-2003 (`.xls`), XBRL, SOAP (WSDL) web services, XQuery/Java/C#/C++
code generation, and the debugger. XSLT generation covers XML (and in 3.0 JSON) sources and targets; constructs XSLT 1.0 cannot
express (e.g. sequences of atomic values) are reported with a clear error.

## Install

Download the installer for your system from **https://skuirrels.github.io/mapster-releases/**
(also attached to the latest release of the public `mapster-releases` repo):

| System | Installer | Notes |
|---|---|---|
| Windows 10/11 | `Mapster-Windows-Setup.exe` or `Mapster-Windows.msi` | The setup.exe can install for the current user without admin rights. Uses the built-in WebView2 runtime (downloaded automatically if missing). |
| macOS 10.15+ | `Mapster-macOS-AppleSilicon.dmg` or `Mapster-macOS-Intel.dmg` | Drag Mapster to Applications. Unsigned builds: right-click the app > Open the first time. |
| Linux | `.deb` (Debian/Ubuntu), `.rpm` (Fedora/openSUSE) or `.AppImage` (any distribution) | `sudo apt install ./Mapster-Linux-amd64.deb`, `sudo dnf install ./Mapster-Linux-x86_64.rpm`, or `chmod +x` the AppImage and run it. |

Every installer registers `.mfd` (MapForce) and `.mmap` (Mapster) files, so double-clicking a
mapping opens it. The `mapster-tools-*` archives on the same page contain `mapster-cli`
and the `mapster-mcp` server for each platform.

### Command-line tool

Every installer also ships `mapster-cli`, so mappings run from a terminal without Rust or Cargo.
Choose **Help ▸ Install Command-Line Tool…** once to put it on your PATH:

| System | What it does |
|---|---|
| macOS | Links `/usr/local/bin/mapster-cli` to the copy inside `Mapster.app` (asks for an administrator password). Move Mapster to Applications first. |
| Windows | Adds the Mapster install folder to your user Path. Open a new terminal afterwards. |
| Linux | The `.deb` and `.rpm` already install `/usr/bin/mapster-cli`. Other installs get a link in `~/.local/bin`; the AppImage can't, so use the tools archive. |

Then run a mapping. Without `--input` it reads the input file the mapping names; `--input` reads
another file instead (add `NAME=` to pick the source component when the mapping has several):

```bash
mapster-cli run mapping.mfd --input message.xml --out out
```

| Command | What it does |
|---|---|
| `mapster-cli run <mapping> [--input [NAME=]FILE]... [--out DIR] [--stdout] [--target NAME] [-p NAME=VALUE]...` | Run a `.mfd` or `.mmap` mapping and write each target's output file (into `DIR` when given; it is created if missing) |
| `mapster-cli xslt <mapping> [--version 1\|2\|3] [--out DIR]` | Generate XSLT for each target |
| `mapster-cli convert <mapping.mfd> <out.mmap>` | Convert a MapForce mapping to a Mapster mapping |
| `mapster-cli functions` | List the function library |

### Building and publishing installers

Mapster is released like every app on the release kit; the process, commands and machine setup
are in [scripts/release-kit/README.md](scripts/release-kit/README.md). Nothing is built on GitHub
Actions (CI only tests, on Linux).

1. On either machine:
   ```bash
   make bump
   ```
   Then commit and push it. `make bump` sets the version in `src-tauri/tauri.conf.json`, `package.json`, both Cargo manifests and `Cargo.lock`.
2. On the Windows PC:
   ```bash
   git pull && make release
   ```
   That builds the Windows installers and tools, then Linux in WSL Ubuntu-22.04, then publishes both.
3. On the Mac:
   ```bash
   git pull && make release
   ```
   That builds Apple Silicon and Intel, with their tools, then publishes them.

`make help` lists the other targets (`installers`, `linux`, `publish`, `publish-dry-run`, `version`,
`clean`). Mapster's settings (site, feeds, the CLI tools archives, the download page text) are
in [release.config.mjs](release.config.mjs).

### Updates

Installed copies check for updates a few seconds after start-up, and on **Help ▸ Check for
Updates…**, and offer to install a newer version (then restart). They read their platform's feed,
`updates/<os>-<arch>.json` on the download site, then `update.json`. Copies installed before 0.3.13
read only `update.json`. A platform not published yet for a new version keeps its users on their
version until it is.

The update bundles are signed with the updater key at `~/.tauri/mapster-updater.key` (password
in `~/.tauri/mapster-updater.key.password`). Copy both files to every build machine and back them up:
the app only installs updates signed with this key (its public half is `plugins.updater.pubkey`
in `src-tauri/tauri.conf.json`), so if the key is lost, users have to reinstall by hand.

Signing the installers themselves is optional. Without it Windows shows an "unknown publisher" SmartScreen prompt and macOS
asks for confirmation on first launch. For a signed and notarized macOS build, set
`APPLE_SIGNING_IDENTITY`, `APPLE_ID`, `APPLE_PASSWORD` and `APPLE_TEAM_ID` in the environment before
`make release` on the Mac; for Windows see the Tauri code-signing guide.

## Layout

| Path | Contents |
|---|---|
| `crates/mapster-core` | Mapping model, XSD/JSON/CSV/FlexText/EDI/Excel loaders, `.mfd` importer, execution engine, function library, JSON command API |
| `crates/mapster-cli` | `mapster-cli` (run / convert / functions / serve) |
| `crates/mapster-mcp` | `mapster-mcp`, an MCP server that lets Claude build and run mappings (see below); also the tools of the app's AI assist |
| `src-tauri` | Desktop shell exposing the core API to the UI, and the AI assist connector (`ai.rs`) |
| `src` | React + React Flow editor |
| `tests/conformance` | Golden cases generated with MapForce (`re/com/golden_all.ps1`) |
| `fixtures` | Sample schemas and data used by tests |
| `re` | Reverse-engineering notes and scripts (see `re/FINDINGS.md`) |

## Development

Prerequisites: Rust (stable), Node.js 20+, and the [Tauri prerequisites](https://tauri.app/start/prerequisites/) for your OS.

```bash
npm install
```

```bash
npm run tauri dev
```

Run the engine tests (unit, MapForce conformance, format round-trips, and generated XSLT run
through `pwsh` + .NET and `npx xslt3`, each skipped if not installed):

```bash
cargo test -p mapster-core
```

Run a mapping from the command line:

```bash
cargo run -p mapster-cli -- run tests/conformance/groupby/mapping.mfd --stdout
```

Generate XSLT for a mapping:

```bash
cargo run -p mapster-cli -- xslt tests/conformance/nested_context/mapping.mfd --version 2
```

Build release bundles for the current platform:

```bash
npm run tauri build
```

### Working on the UI in a browser

`mapster-cli serve` exposes the same command API over HTTP on `127.0.0.1:7878`, so the UI can be
developed in a regular browser with `npm run dev`. Without Tauri's native dialogs, file paths are
entered in a prompt. `?open=<path>` opens a mapping on startup.

## AI assist

Claude can change the open mapping for you: "join First and Last with a space into FullName",
"only map people older than 30", "why is Total empty?".

- **Your own plan, no API key:** Mapster runs the [Claude Code](https://code.claude.com) or
  [Codex](https://github.com/openai/codex) command-line tool you have installed, so requests count against
  your Claude or ChatGPT plan. Set it up in *AI ▸ AI Settings…*: turn AI on, pick Claude Code or Codex, and
  optionally a model or the program's location (it's found on PATH and in the usual install folders).
  *Check Connection* shows the version and whether it's signed in, and *Sign In…* starts the tool's own
  browser sign-in.
- **AI panel** (*AI* in the toolbar, `Ctrl+Shift+A`): ask for a change or a question. The panel shows each
  step the AI takes (looking at the mapping, adding a function, connecting ports, running the mapping),
  then its answer and a list of what it changed: components and connections added, removed or changed.
  **Apply Changes** puts them into the mapping as one step that `Ctrl+Z` undoes; *Discard* drops them.
  Components selected on the canvas are mentioned, so "format these as dates" works.
- **Fix with AI:** hover over a problem in Messages (from Validate, Run or Live preview), or use
  *AI ▸ Fix Problems with AI…* for everything Validate reports. **Explain with AI** is on every component's
  right-click menu, and *AI ▸ Explain Mapping…* explains the whole mapping.
- **Off until you turn it on, and you see what's sent:** nothing is sent while AI is off. Commands show the
  exact text in a dialog and send it only when you click *Send*; the line under the chat input says what
  the AI can reach.
- **Locked down:** the AI works on a scratch copy of the mapping in a temporary folder and never touches
  your files. Claude Code runs with all of its own tools (files, shell, web) and your MCP servers off; its
  only tools are Mapster's MCP tools, served by the app itself (`--mcp-server`) and limited to that copy:
  no creating, importing or writing files, and run results are returned, not written. Codex runs in its
  read-only sandbox with the same tools added. Untick *Input files* to keep the mapping's input data away
  from the AI as well: it then can't run the mapping or read sample values. API-key environment variables
  (`ANTHROPIC_API_KEY` and similar) aren't passed to Claude Code, so it uses your plan sign-in.
- If the mapping changed while the AI was working, *Apply Changes* asks first, since applying replaces
  those edits (Undo still brings them back). User-defined function bodies can't be changed by the AI yet.

## Use with Claude (MCP)

`mapster-mcp` is a [Model Context Protocol](https://modelcontextprotocol.io) server (stdio) that lets
Claude build, inspect and run mappings: it reads schemas, adds components, draws connections, validates,
runs the mapping and shows the output. Mappings are ordinary `.mmap` files, so whatever Claude builds opens
in the desktop app (and vice versa). MapForce `.mfd` files can be inspected, validated, run and turned into
XSLT directly, or converted to `.mmap` with `import_mfd` for editing.

Build it:

```bash
cargo build --release -p mapster-mcp
```

Register it with Claude Code (run in the folder that holds your data; relative paths resolve against the
server's working directory, which is where Claude Code was started):

```bash
claude mcp add mapster -- /path/to/Mapster/target/release/mapster-mcp
```

On Windows the binary is `target\release\mapster-mcp.exe`. For a project-scoped setup, copy
[`.mcp.json.example`](.mcp.json.example) to `.mcp.json` and adjust the command path.

Claude Desktop: add the server to `claude_desktop_config.json` (Settings → Developer → Edit Config) and
restart the app. Claude Desktop starts servers in its own working directory, so use absolute paths in prompts.

```json
{
  "mcpServers": {
    "mapster": {
      "command": "C:\\path\\to\\Mapster\\target\\release\\mapster-mcp.exe"
    }
  }
}
```

Tools:

| Tool | Purpose |
|---|---|
| `describe_file` | Structure of an XSD / XML / JSON Schema / JSON / CSV / Excel file as a tree of paths (the port names), with `*` repeating, `?` optional and types; candidate XSD roots |
| `create_mapping` | New empty `.mmap` |
| `inspect_mapping` | Components with ids and ports, structures, connections (`id:port -> id:port`), user functions, validation issues |
| `add_structure` | Add a source (with `input`) or target (with `output`) document from a schema or data file |
| `add_function`, `add_constant`, `add_component` | Library functions (or calls of user functions), constants, filter / if-else / value-map / sort / input parameter / output |
| `connect`, `disconnect`, `remove_component` | Edit connections (an input takes one connection; reconnecting replaces it) and components |
| `auto_map` | Name- and structure-based connections from a source to a target document |
| `validate_mapping`, `run_mapping` | Check for problems; run and return each target's output (optionally writing the files) |
| `generate_xslt` | XSLT 1.0 / 2.0 for XML-to-XML mappings |
| `sample_values` | Example values per path from a source's input file |
| `list_functions` | Search the function library |
| `import_mfd` | Convert a MapForce `.mfd` to `.mmap` |

Every editing tool loads the `.mmap`, applies the change, saves it atomically and reports what changed
(new component ids, port names, replaced connections).

`--session <file.mmap> [--base-dir <dir>] [--no-data]` limits the server to one mapping, as the desktop
app's AI assist uses it: the `mapping` argument is dropped, `create_mapping`, `import_mfd` and
`generate_xslt` are left out, `run_mapping` doesn't write outputs, relative paths resolve against
`--base-dir`, and `--no-data` also leaves out the tools that read input files.

Example prompt:

> Using mapster, create `contacts.mmap` that maps `fixtures/basic/company.xml` (schema
> `fixtures/basic/company.xsd`) to `fixtures/basic/contacts.xsd`, writing `out/contacts.xml`. One Contact per
> Person; FullName is First + " " + Last, Dept is the department name, Senior is true when Age > 40, and
> Total is the number of people. Validate it, run it and show me the output.

## How compatibility was established

See [`re/REA.md`](re/REA.md) and [`re/FINDINGS.md`](re/FINDINGS.md). In short: MapForce 2022's
executable was analyzed with [rea](https://github.com/morluto/rea) (artifact inventory, PE
resources, and native analysis with rea's Ghidra provider) (PE resources: menus, dialogs, string tables, embedded rule
files), its function-library descriptors and help were mined for signatures and behavior, and its
COM automation API was used to create `.mfd` files and run its built-in engine on Mapster's own
test fixtures. Those runs produce the golden outputs in `tests/conformance`. No Altova code or
assets are included in Mapster.
