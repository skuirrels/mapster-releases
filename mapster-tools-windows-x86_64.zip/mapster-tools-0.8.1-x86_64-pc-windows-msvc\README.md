# Mapster

A cross-platform visual data-mapping tool built with [Tauri](https://tauri.app), Rust and React: an
independent alternative to Altova MapForce. Draw lines between the nodes of a source and a target
structure, insert functions, filters and lookups, and run the mapping to produce XML, JSON, CSV,
fixed-length or free-form text, EDI or Excel workbooks.
Mapster also opens MapForce `.mfd` mapping designs directly.

![icon](src-tauri/icons/128x128.png)

## Features

- **Structures**: XML (from XML Schema or inferred from an instance), JSON (from JSON Schema or an
  instance), CSV (header row or positional fields), fixed-length text (field widths and fill
  character), FlexText (MapForce `.mft` templates that split free-form text into fragments by
  lines, separators, regular expressions and switch conditions, store them as values, CSV or
  fixed-length records, and write the same layout back), and EDI: ANSI X12 (including HIPAA),
  UN/EDIFACT (including IATA), HL7 v2 (separators from the MSH segment, sub-components, escape
  sequences, multi-message files selected by MSH-9), TRADACOMS and SAP IDocs (from an SAP parser
  file), read and written with envelope auto-completion (ISA/GS/ST/SE/GE/IEA,
  UNA/UNB/UNH/UNT/UNZ, counts and control numbers) and the parser results MapForce uses for 997/999
  acknowledgments. Excel 2007+ workbooks (`.xlsx`) are laid out like MapForce lays them out:
  worksheets by name (or all of them), row ranges that start at a row or after the previous range,
  hold a fixed or dynamic number of rows and may begin with a header row, and cells as typed columns
  or as one item per cell with its column number; dates, times and numbers become typed cells.
  Apache Avro object container files (`.avro`, with the `null`, `deflate`, `snappy` and
  `zstandard` codecs) and Avro's JSON encoding, from an Avro schema (`.avsc`) or the schema an
  `.avro` file embeds.
  Any structure can be a source, a target, or an intermediate step of a chained mapping.
- **Visual editor**: schema trees with expandable nodes, drag-to-connect, function library with
  search and drag & drop, component settings, undo/redo, output preview, messages pane, and
  MapForce's context menus: right-click the canvas (insert input/output/constant, cut/copy/paste,
  function settings), a component (change root, refresh, find, align tree, create mapping to XML
  or to an X12 997/999 acknowledgment, priority context, inline a user-defined function call), a
  connection (connect matching children, go to source/target, connection type, insert
  sort/filter/value-map) or a structure node (duplicate inputs before/after, move up/down, delete
  connections, create variables, compute once). As in MapForce, a connection's end can be dragged
  to another node (Ctrl+drag copies it; the connections below it can come along), connecting to an
  input that already has one offers to replace it or duplicate the input, hovering a connection
  names both ends, components snap into line with each other while dragged, and the toolbar can
  dim every connection except the selected components' (optionally traced from source to target).
  Selecting a component colours its connections, followed through functions to their sources and
  targets.
- **Mapster view** (toolbar toggle) for busy mappings: connected constants are shown as values at
  the ports they feed (click to edit, × to disconnect) instead of as components, and the canvas is
  laid out in columns: sources and parameters on the left, functions in between level with the
  ports they feed, targets on the right. It changes only what is drawn; the mapping keeps its
  MapForce layout, which the standard view shows.
- **Transformations**: ~150 built-in functions (string, math, logical, conversion, date/time
  pictures, sequence, aggregates with parent context, grouping, file paths, null handling), constants,
  input parameters, filters (on-true/on-false), if-else chains, value-maps, multi-key sort,
  priority context, copy-all connections and user-defined functions (created and edited in
  their own tabs; call sites follow parameter and result changes automatically).
- **MapForce compatibility**: imports `.mfd` (XML, JSON, CSV, fixed-length, FlexText, X12, EDIFACT, HL7,
  TRADACOMS, IDoc and Excel 2007+ components, "parse string" components, mixed-content text, functions, filters,
  if-else, value-maps, sort, constants, parameters, user-defined functions, priority context, copy-all,
  duplicate inputs, simple and structured variables with compute-when, and joins). The engine
  reproduces MapForce's execution semantics; `tests/conformance` holds mappings together with the
  output that MapForce itself produced for them, and Mapster must match each one. MapForce's own
  example mappings are compared the same way when a copy of them is present (`re/samples/mfx`,
  see `crates/mapster-core/tests/examples.rs`).
- **Mapping assistance**: ✨ Auto-map (fuzzy, synonym-aware name matching that respects the
  structure hierarchy), auto-connect matching children when two parent nodes are connected,
  Validate (dangling ports, unconnected required inputs and target nodes), live output preview,
  sample values from the input file shown on every source node, and automatic reload when the
  open mapping changes on disk (e.g. edited by Claude through the MCP server).
- **AI assist** (*AI* toolbar button, *AI* menu, `Ctrl+Shift+A`): ask Claude to change or explain
  the mapping, and have it fix problems Validate or a run reports. It uses your own Claude Code or
  Codex sign-in, edits a copy of the mapping with Mapster's own tools, and you apply what it
  changed (see [AI assist](#ai-assist)).
- **Code generation**: XSLT 1.0, 2.0 and 3.0 stylesheets (toolbar XSLT button, File menu, or
  `mapster-cli xslt --version 1|2|3`). 1.0 and 2.0 cover XML sources and targets; 3.0 also reads
  JSON sources (`json-to-xml`) and writes JSON targets (`xml-to-json`). Generated stylesheets are
  tested with .NET (XSLT 1.0) and SaxonJS (XSLT 2.0 and 3.0) against the MapForce reference outputs.
  File ▸ Generate Code (or `mapster-cli codegen --lang csharp|java|cpp`) writes a C# (.NET 10),
  Java (Maven, Java 25) or C++ (CMake) project with a typed class for the mapping (see
  [Generated code](#generated-code)).
- **.NET and Java function libraries**: add a `.dll` or `.jar` (Tools ▸ Add .NET or Java
  Library…) and its public static methods become functions you can drag onto the mapping.
- **Global resources** (Tools ▸ Global Resources…): files, folders, connection strings and text
  with a value per configuration (Default, Production, ...), referred to as `${global:Name}` and
  switched with the toolbar's configuration list or `mapster-cli --config NAME`.
- **Opening files**: Open… (Ctrl+O) reads `.mmap` and MapForce `.mfd`; installed bundles register
  both extensions, so double-clicking a `.mfd` opens it in Mapster.
- **Headless runs**: `mapster-cli run mapping.mfd` executes a mapping without the UI.

EDI structures come from MapForce's EDI configuration files, which are not redistributed: they are
read from a MapForce installation (`C:\Program Files\Altova\MapForce20xx\MapForceEDI`), from
`~/.mapster/edi` (copy the MapForceEDI folder there on macOS and Linux), from the folders in
`MAPSTER_EDI_CONFIG`, or next to the mapping. FlexText templates (`.mft`) and SAP IDoc parser
files belong to the mapping and are read next to it; a FlexText source without an input file reads
the sample file its template names. Templates are made and changed in the FlexText designer
(File ▸ New/Open FlexText Template…, a FlexText component's Edit FlexText Template…, or Edit… in
its settings), which shows the fragment of the sample text each container receives as you edit and
saves `.mft` files in MapForce's layout.

MapForce designs import with generic nodes (`element()`, dynamic node and JSON member names), mixed
content, user-defined functions with structured (XML) parameters and results, recursive functions,
node functions and defaults ("rules"), and designs from old MapForce versions.

Functions from libraries are imported with the design: user-defined functions of other `.mfd`
files and named templates of XSLT stylesheets, which run in the engine and become
`xsl:call-template` (with an `xsl:include` of the stylesheet) in generated XSLT. Libraries the design
imports itself (`settings/libraries`) come first; MapForce's global libraries are an application
setting, so the files of a MapForce project (`.mfp`) listing the design, then the other designs and
stylesheets in its folder, stand in for them (the import warnings name each library found that way).
Functions are matched by library and name, so libraries may define functions of the same name.

Excel targets are written as new workbooks holding data only (like MapForce's "overwrite existing
file"); MapForce's "update existing file" option is kept but also writes a new workbook. Named ranges
and tables are not read. The output preview shows a workbook as MapForce's XML view of it
(`Workbook/Worksheet/Row/Cell`); "Save output…" writes the `.xlsx`.

REST web service calls (Insert ▸ Web Service Call (REST)…, or MapForce's web service component
imported from a design) send their request with the mapped URL, parameters, headers and JSON or XML
body, and read the status, headers and the response body chosen by status. Request and response
bodies take their structure from an XML Schema or JSON Schema, or from a sample document. A call
is made either for every input, like an inline function (once per item connected to `Request`,
else wherever its response is read), or once per run, with every connection reading the same
response (a login, a token, a lookup list). Requests can be authenticated with HTTP Basic, a
custom header or API key (as a header or query parameter), or OAuth 2.0 (client credentials,
password and refresh-token grants, or an access token you already have); OAuth tokens are reused
until they expire and renewed after a 401. Any authentication field may hold `${NAME}`, read when
the mapping runs from the input parameter or environment variable of that name, so secrets need
not be saved in the mapping. Calls are made only when the mapping is run (Run, or
`mapster-cli run`); Live preview does not send requests.

SOAP web services are called the same way. In a web service component's settings, give the WSDL
(a file or an `http(s)://` URL) and choose an operation of one of its SOAP 1.1 or 1.2 ports: the
endpoint, `SOAPAction` and the request and response bodies come from the WSDL, with the bodies
typed by the schemas in its `types` (document/literal, and rpc/literal with a wrapper element named
after the operation). The request body is sent in a SOAP envelope, and the response is read from
the envelope's body; a SOAP fault stops the run with its code and text. WSDL 2.0, SOAP headers,
attachments and WS-Security are not supported.

Databases (SQLite, PostgreSQL, SQL Server and Oracle) come in two kinds of component. Insert ▸ Database
Tables… connects to a database and shows the tables you choose, read from its catalogue with their
column types and keys. Connected from, a table is read row by row, with an optional `WHERE`
condition and `ORDER BY`; connected to, every row written becomes an insert, update, merge (update
the row with the same keys, else insert it) or delete, keyed by the primary key or the columns you
name, optionally after deleting every row. Insert ▸ Database Call… runs a query or statement with
`:name` parameters, a function (scalar or table-valued) or a stored procedure. Its parameters,
read from the SQL or the routine's declaration, are the inputs under `Parameters` (unless given a
fixed value), and its outputs under `Result` follow the established result columns:
`ResultSet/Row/<column>` (`ResultSet2`, … for further result sets), a procedure's `Output/<name>`
parameters and SQL Server `ReturnValue`, and a statement's `RowsAffected`. Result columns the
database cannot describe beforehand are read by running the call once inside a transaction that is
rolled back. Like web services, a call runs for every input or once per run. Connection strings
may hold `${NAME}`. Each database gets one connection and one transaction per run, committed only
when the whole run succeeds; previews read tables and run queries and functions but never change
the database (statements and procedures are left out, and table targets show the SQL they would
run). SQL Server needs SQL authentication (Windows integrated authentication is not supported).
Oracle connects through Oracle Instant Client (Basic or Basic Light), which has to be installed
where the mapping runs: on macOS and Windows Mapster finds an `instantclient_*` folder in your home
folder, Downloads, `/opt/oracle` or `C:\oracle` (or the folder `MAPSTER_ORACLE_CLIENT` names); on
Linux the client's folder has to be in `LD_LIBRARY_PATH` or the `ldconfig` path. Its connection
string is `Data Source=host:1521/service;User Id=…;Password=…`, where the data source is anything
Oracle Net takes (EZConnect, a TNS alias or a connect descriptor; JDBC's `host:port:SID` works
too). Dates and numbers are read as XML Schema values, functions and procedures (also in packages)
are called with their `OUT` parameters as outputs, and PL/SQL blocks may return result sets with
`DBMS_SQL.RETURN_RESULT`.
MapForce database components import with their data source: tables become a database component
(columns as shown in the design, written with Insert All), and SQL SELECT statements, stored
procedures and functions become database calls. Passwords are not imported: each connection reads
its password from `${<DATA SOURCE>_PASSWORD}` (for example `SYNAPSEEDI_PASSWORD`). Oracle data
sources connect like the others once Oracle Instant Client is installed.

MongoDB collections (Insert ▸ MongoDB Collection…) are sources and targets. A collection's structure is a
repeating `Document` whose members come from a JSON Schema (MongoDB's `$jsonSchema` with
`bsonType`, or plain JSON Schema), from the collection's validator, or from sample documents read
from the server. Every document written becomes an insert, update, upsert, replace or delete keyed
by `_id` or the fields you name, optionally after clearing the collection. Values are converted
by the type of their node (`objectId`, `date`, `int`, `long`, `double`, `decimal`, `bool`,
strings, objects, arrays and null). The writes are made only when the whole run succeeds, in one
transaction when the server supports it (a replica set or sharded cluster); the preview shows them
as a script and changes nothing. Connection strings may hold `${NAME}` and `${global:Name}`.
Connected from, a collection is read with an optional filter, projection and sort (Extended JSON,
such as `{"status": "open", "total": {"$gt": 100}}`, which may hold `${NAME}`) and a limit; values
are read as text, with dates as `xs:dateTime` and ObjectIds in hex.

Apache Avro components read and write object container files (`.avro`) or Avro's JSON encoding
(one object per line). Their structure comes from an Avro schema (`.avsc`, or a `.json` file that
holds one); a source can do without one, since an `.avro` file holds its schema. The tree is
`Objects` with one repeating node per object, named after the top-level record. Records list their fields, arrays have a repeating `item`,
and maps a repeating `entry` with `key` and `value`. A `["null", T]` field is an optional node: a
null reads as no node, and a field with nothing mapped to it writes null. Where no node would lose
the null (an array item, a map value, a top-level object, or a field whose default is not null)
it reads as a nil node, which copies and field connections carry through and which writes null.
Any other union has one node per branch (`int`, `string`, or the record's name), of which reading
fills one and writing uses the first that has a value. A field that is given more than one value
is an error. Values are text as XML Schema writes them: decimals exactly, up to 10,000 digits;
`date`, `time-*` and `timestamp-*` as `xs:date`, `xs:time` and `xs:dateTime`
(UTC with `Z`, `local-timestamp-*` without a time zone); `duration` as `xs:duration`; enums as their
symbols; `bytes` and `fixed` in base64. When writing, a field with nothing mapped to it gets its
schema default, else null where the type allows it; an unmapped array or map is written empty, and
any other missing value is an error naming its path. Decimals are rounded half away from zero to
the schema's scale. Targets choose the codec (default `deflate`), objects per block and extra file
metadata; the preview shows the objects as readable JSON, one per line (union values unwrapped,
decimals, dates and times as text). To keep a small file from using unbounded memory, Mapster reads
at most 100 million values per file, and at most a million items that hold no data (nulls, records
without fields); a structure is limited to 200,000 nodes. A separate reader schema (schema
resolution), single-object and Kafka (Confluent) framing are not supported. MapForce has no Avro
support, so these rules are Mapster's own; they are tested against the Apache `apache-avro`
implementation.

XML targets write derived types, `xsi:nil`, CDATA, comments and processing instructions. An
element whose schema type has derived types shows them as extra nodes (`Address(USAddress)`;
right-click ▸ Show Derived Type…), and mapping to one writes `xsi:type`. `set-xsi-nil` writes an
element empty with `xsi:nil="true"`, `substitute-missing-with-xsi-nil` does so when there is no
value, `is-xsi-nil` tests a source element, and copy-all connections keep both. Right-click an
element ▸ Write Content as CDATA writes its text as a CDATA section, and Comments and Processing
Instructions adds a port before or after the element whose value becomes a comment or processing
instruction next to every instance. Generated XSLT writes all of these too.

Functions of .NET and Java libraries run in a helper process that Mapster builds the first time it
needs one (it needs the .NET SDK or a JDK on that machine), in Run, Live preview and
`mapster-cli`. Each public static method is a function named `Class.Method`, with parameters and a
result of a simple type (string, integer and floating-point numbers, decimal or `BigDecimal`,
boolean); a `null` result is no value, and an exception stops the run with its message. The helper
restarts when the library file changes. Mappings that call such functions cannot be generated as
XSLT.

Global resources are kept in `~/.mapster/global-resources.json` (or the file `MAPSTER_GLOBAL_RESOURCES`
or `--resources FILE` names). A `${global:Name}` reference may stand anywhere a file, folder or
connection string goes: input and output files, schemas, database and MongoDB connection strings,
web service URLs and authentication. An empty value in the active configuration falls back to the
first one.

### Generated code

The generated projects run the mapping with Mapster's own engine, so their output is exactly what
Mapster writes. Each project holds the mapping (with its schemas, sample inputs and libraries), the
native engine library `mapster_ffi` for the platform it was generated on, a typed class with a
property for each parameter and source and a `Run()` that returns the outputs, and a small command
line program (`--param NAME=VALUE`, `--input [NAME=]FILE`, `--out DIR`, `--stdout`). The project's
README says how to build it:

| Language | Project | Build | Needs |
|---|---|---|---|
| C# | `.csproj`, `net10.0` | `dotnet build` | .NET 10 SDK |
| Java | Maven `pom.xml` | `mvn package` | JDK 25 or later (the Foreign Function API) |
| C++ | `CMakeLists.txt` | `cmake -S . -B build && cmake --build build` | CMake and a C++20 compiler |

In C# and Java, functions of .NET and Java libraries are called directly from the generated code;
C++ calls them through the helper process. The C API itself is in
[`crates/mapster-ffi/include/mapster.h`](crates/mapster-ffi/include/mapster.h) for use from other
languages. To generate for another platform, pass that platform's library with `--native`.

Decision tables (Insert ▸ Decision Table…, or MapForce's decision table) try their rules from the
top and give the outputs of the first rule whose conditions all hold. A condition is `-`
(anything), a value, a comparison (`<10`, `>=A`, `!=X`), a range (`1..5`) or several of these
separated by commas; values compare as numbers when both are numbers, and equality is exact, so
`006` does not match `6`.

The file line of a document is its file name port (MapForce's `File:` node). Connected from a
source, it gives the name of the file read; connected to a target, every item names a file of its
own, written with that item as the context of the structure below (dynamic output file names).
A source reads several files when its input file is a wildcard (`orders/*.xml`, `day-??.csv`: every
match, in name order) or when names are connected to its file name port (dynamic input file
names). Each file is a document of its own: connections from the source read all of them in turn,
and its file name port gives each file's name with that file as the context, so connecting it to a
target's file name port writes one output per input file. The structure comes from the schema, or
from the first file that matches. XSLT generation does not support such sources.

The debugger (Output ▸ Debug Mapping, or Debug on the toolbar) runs the mapping and records every
step: each value a component computes and each target node written, with the source nodes it was
computed for. Step forwards and backwards through them, or select components and set breakpoints
on them to continue to the next step there; the canvas marks the step's component, the output its
value comes from, and the sources in context. Debugging calls web services but never writes to
databases or MongoDB collections.

Not yet supported: JSON Lines, database engines other than SQLite, PostgreSQL, SQL Server and
Oracle, MapForce table actions other than Insert All, SWIFT MT and other fixed-length EDI, Excel
97-2003 (`.xls`), XBRL, importing MapForce's SOAP web service components, and XQuery generation.
XSLT generation covers XML (and in 3.0 JSON) sources and targets; constructs XSLT 1.0 cannot
express (e.g. sequences of atomic values) are reported with a clear error.

## Install

Download the installer for your system from **https://skuirrels.github.io/mapster-releases/**
(also attached to the latest release of the public `mapster-releases` repo):

| System | Installer | Notes |
|---|---|---|
| Windows 10/11 | `Mapster-Windows-Setup.exe` or `Mapster-Windows.msi` | The setup.exe can install for the current user without admin rights. Uses the built-in WebView2 runtime (downloaded automatically if missing). |
| macOS 10.15+ | `Mapster-macOS-AppleSilicon.dmg` or `Mapster-macOS-Intel.dmg` | Drag Mapster to Applications. Unsigned builds: right-click the app > Open the first time. |
| Linux | `.deb` (Debian/Ubuntu), `.rpm` (Fedora/openSUSE) or `.AppImage` (any distribution) | `sudo apt install ./Mapster-Linux-amd64.deb`, `sudo dnf install ./Mapster-Linux-x86_64.rpm`, or `chmod +x` the AppImage and run it. |

Every installer registers `.mfd` (MapForce) and `.mmap` (Mapster) files, so double-clicking a
mapping opens it. The `mapster-tools-*` archives on the same page contain `mapster-cli`
and the `mapster-mcp` server for each platform.

### Command-line tool

Every installer also ships `mapster-cli`, so mappings run from a terminal without Rust or Cargo.
Choose **Help ▸ Install Command-Line Tool…** once to put it on your PATH:

| System | What it does |
|---|---|
| macOS | Links `/usr/local/bin/mapster-cli` to the copy inside `Mapster.app` (asks for an administrator password). Move Mapster to Applications first. |
| Windows | Adds the Mapster install folder to your user Path. Open a new terminal afterwards. |
| Linux | The `.deb` and `.rpm` already install `/usr/bin/mapster-cli`. Other installs get a link in `~/.local/bin`; the AppImage can't, so use the tools archive. |

Then run a mapping. Without `--input` it reads the input file the mapping names; `--input` reads
another file instead (add `NAME=` to pick the source component when the mapping has several):

```bash
mapster-cli run mapping.mfd --input message.xml --out out
```

| Command | What it does |
|---|---|
| `mapster-cli run <mapping> [--input [NAME=]FILE]... [--out DIR] [--stdout] [--target NAME] [-p NAME=VALUE]...` | Run a `.mfd` or `.mmap` mapping and write each target's output file (into `DIR` when given; it is created if missing) |
| `mapster-cli xslt <mapping> [--version 1\|2\|3] [--out DIR]` | Generate XSLT for each target |
| `mapster-cli codegen <mapping> --lang csharp\|java\|cpp --out DIR [--name NAME] [--namespace NS] [--native LIBRARY]` | Generate a C#, Java or C++ project that runs the mapping |
| `mapster-cli build <mapping> -o PROGRAM [--runtime MAPSTER-CLI]` | Write one program with the mapping inside (see below) |
| `mapster-cli convert <mapping.mfd> <out.mmap>` | Convert a MapForce mapping to a Mapster mapping |
| `mapster-cli functions` | List the function library |

Every command also takes `--config NAME` (the global resource configuration to use) and
`--resources FILE` (another global resource file).

`mapster-cli build` writes a standalone program: a copy of `mapster-cli` with the mapping and the
files it reads (schemas, sample inputs, templates and libraries) embedded, so it runs on a machine
with nothing else installed. It takes the options of `mapster-cli run` without the mapping, and
writes its outputs to the current folder unless `--out` or `--stdout` says otherwise:

```bash
mapster-cli build orders.mfd -o convert-orders
./convert-orders --input 'incoming/*.xml' --out converted
```

The program is for the system `mapster-cli` runs on (on macOS it is signed ad hoc, so Gatekeeper
accepts it locally). To build for another system, pass that system's `mapster-cli` from its tools
archive with `--runtime`. Mappings that call .NET or Java libraries still need the .NET SDK or a
JDK where they run, and Oracle mappings need Oracle Instant Client.

### Building and publishing installers

Mapster is released like every app on the release kit; the process, commands and machine setup
are in [scripts/release-kit/README.md](scripts/release-kit/README.md). Nothing is built on GitHub
Actions (CI only tests, on Linux).

1. On either machine:
   ```bash
   make bump
   ```
   Then commit and push it. `make bump` sets the version in `src-tauri/tauri.conf.json`, `package.json`, both Cargo manifests and `Cargo.lock`.
2. On the Windows PC:
   ```bash
   git pull && make release
   ```
   That builds the Windows installers and tools, then Linux in WSL Ubuntu-22.04, then publishes both.
3. On the Mac:
   ```bash
   git pull && make release
   ```
   That builds Apple Silicon and Intel, with their tools, then publishes them.

`make help` lists the other targets (`installers`, `linux`, `publish`, `publish-dry-run`, `version`,
`clean`). Mapster's settings (site, feeds, the CLI tools archives, the download page text) are
in [release.config.mjs](release.config.mjs).

### Updates

Installed copies check for updates a few seconds after start-up, and on **Help ▸ Check for
Updates…**, and offer to install a newer version (then restart). They read their platform's feed,
`updates/<os>-<arch>.json` on the download site, then `update.json`. Copies installed before 0.3.13
read only `update.json`. A platform not published yet for a new version keeps its users on their
version until it is.

The update bundles are signed with the updater key at `~/.tauri/mapster-updater.key` (password
in `~/.tauri/mapster-updater.key.password`). Copy both files to every build machine and back them up:
the app only installs updates signed with this key (its public half is `plugins.updater.pubkey`
in `src-tauri/tauri.conf.json`), so if the key is lost, users have to reinstall by hand.

Signing the installers themselves is optional. Without it Windows shows an "unknown publisher" SmartScreen prompt and macOS
asks for confirmation on first launch. For a signed and notarized macOS build, set
`APPLE_SIGNING_IDENTITY`, `APPLE_ID`, `APPLE_PASSWORD` and `APPLE_TEAM_ID` in the environment before
`make release` on the Mac; for Windows see the Tauri code-signing guide.

## Layout

| Path | Contents |
|---|---|
| `crates/mapster-core` | Mapping model, XSD/JSON/CSV/FlexText/EDI/Excel loaders, `.mfd` importer, execution engine, function library, JSON command API |
| `crates/mapster-cli` | `mapster-cli` (run / convert / xslt / codegen / functions / serve) |
| `crates/mapster-ffi` | The engine as a C library (`mapster_ffi`), used by generated C#, Java and C++ code |
| `crates/mapster-core/bridge` | The .NET and Java helper programs that run library functions |
| `crates/mapster-mcp` | `mapster-mcp`, an MCP server that lets Claude build and run mappings (see below); also the tools of the app's AI assist |
| `src-tauri` | Desktop shell exposing the core API to the UI, and the AI assist connector (`ai.rs`) |
| `src` | React + React Flow editor |
| `tests/conformance` | Golden cases generated with MapForce (`re/com/golden_all.ps1`) |
| `fixtures` | Sample schemas and data used by tests |
| `re` | Reverse-engineering notes and scripts (see `re/FINDINGS.md`) |

## Development

Prerequisites: Rust (stable), Node.js 20+, and the [Tauri prerequisites](https://tauri.app/start/prerequisites/) for your OS.

```bash
npm install
```

```bash
npm run tauri dev
```

Run the engine tests (unit, MapForce conformance, format round-trips, and generated XSLT run
through `pwsh` + .NET and `npx xslt3`, each skipped if not installed):

```bash
cargo test -p mapster-core
```

Run a mapping from the command line:

```bash
cargo run -p mapster-cli -- run tests/conformance/groupby/mapping.mfd --stdout
```

Generate XSLT for a mapping:

```bash
cargo run -p mapster-cli -- xslt tests/conformance/nested_context/mapping.mfd --version 2
```

Build release bundles for the current platform:

```bash
npm run tauri build
```

### Working on the UI in a browser

`mapster-cli serve` exposes the same command API over HTTP on `127.0.0.1:7878`, so the UI can be
developed in a regular browser with `npm run dev`. Without Tauri's native dialogs, file paths are
entered in a prompt. `?open=<path>` opens a mapping on startup. The API answers only pages from
`http://localhost:1420` (add others with `--allow-origin ORIGIN`) and refuses other host names and
requests that aren't JSON, so other web pages can't use it.

## AI assist

Claude can change the open mapping for you: "join First and Last with a space into FullName",
"only map people older than 30", "why is Total empty?".

- **Your own plan, no API key:** Mapster runs the [Claude Code](https://code.claude.com) or
  [Codex](https://github.com/openai/codex) command-line tool you have installed, so requests count against
  your Claude or ChatGPT plan. Set it up in *AI ▸ AI Settings…*: turn AI on, pick Claude Code or Codex, and
  optionally a model or the program's location (it's found on PATH and in the usual install folders).
  *Check Connection* shows the version and whether it's signed in, and *Sign In…* starts the tool's own
  browser sign-in.
- **AI panel** (*AI* in the toolbar, `Ctrl+Shift+A`): ask for a change or a question. The panel shows each
  step the AI takes (looking at the mapping, adding a function, connecting ports, running the mapping),
  then its answer and a list of what it changed: components and connections added, removed or changed.
  **Apply Changes** puts them into the mapping as one step that `Ctrl+Z` undoes; *Discard* drops them.
  Components selected on the canvas are mentioned, so "format these as dates" works.
- **Fix with AI:** hover over a problem in Messages (from Validate, Run or Live preview), or use
  *AI ▸ Fix Problems with AI…* for everything Validate reports. **Explain with AI** is on every component's
  right-click menu, and *AI ▸ Explain Mapping…* explains the whole mapping.
- **Off until you turn it on, and you see what's sent:** nothing is sent while AI is off. Commands show the
  exact text in a dialog and send it only when you click *Send*; the line under the chat input says what
  the AI can reach.
- **Locked down:** the AI works on a scratch copy of the mapping in a temporary folder and never touches
  your files. Claude Code runs with all of its own tools (files, shell, web), your MCP servers, and your own
  settings, hooks, plugins and `CLAUDE.md` off; its
  only tools are Mapster's MCP tools, served by the app itself (`--mcp-server`) and limited to that copy:
  no creating, importing or writing files, no reading files outside the mapping's folder other than the
  ones it already uses, and run results are returned, not written. Codex runs in its
  read-only sandbox with the same tools added. Untick *Input files* to keep the mapping's input data away
  from the AI as well: it then can't run the mapping or read sample values. API-key environment variables
  (`ANTHROPIC_API_KEY` and similar) aren't passed to Claude Code, so it uses your plan sign-in.
- **Follow-ups build on what you haven't applied yet:** while the last answer's changes wait in the panel
  (and you haven't edited the mapping since), the next request starts from them, so "now also…" works;
  *Apply Changes* on the newer answer applies both.
- **User-defined functions too:** the AI can look inside a function and change its body, and large
  structures are shown to it in outline, with the detail fetched as needed, so big MapForce mappings fit.
- If the mapping changed while the AI was working, *Apply Changes* asks first, since applying replaces
  those edits (Undo still brings them back).

## Use with Claude (MCP)

`mapster-mcp` is a [Model Context Protocol](https://modelcontextprotocol.io) server (stdio) that lets
Claude build, inspect and run mappings: it reads schemas, adds components, draws connections, validates,
runs the mapping and shows the output. Mappings are ordinary `.mmap` files, so whatever Claude builds opens
in the desktop app (and vice versa). MapForce `.mfd` files can be inspected, validated, run and turned into
XSLT directly, or converted to `.mmap` with `import_mfd` for editing.

Build it:

```bash
cargo build --release -p mapster-mcp
```

Register it with Claude Code (run in the folder that holds your data; relative paths resolve against the
server's working directory, which is where Claude Code was started):

```bash
claude mcp add mapster -- /path/to/Mapster/target/release/mapster-mcp
```

On Windows the binary is `target\release\mapster-mcp.exe`. For a project-scoped setup, copy
[`.mcp.json.example`](.mcp.json.example) to `.mcp.json` and adjust the command path.

Claude Desktop: add the server to `claude_desktop_config.json` (Settings → Developer → Edit Config) and
restart the app. Claude Desktop starts servers in its own working directory, so use absolute paths in prompts.

```json
{
  "mcpServers": {
    "mapster": {
      "command": "C:\\path\\to\\Mapster\\target\\release\\mapster-mcp.exe"
    }
  }
}
```

Tools:

| Tool | Purpose |
|---|---|
| `describe_file` | Structure of an XSD / XML / JSON Schema / JSON / CSV / Excel file as a tree of paths (the port names), with `*` repeating, `?` optional and types; candidate XSD roots |
| `create_mapping` | New empty `.mmap` |
| `inspect_mapping` | Components with ids and ports, structures, connections (`id:port -> id:port`), user functions, validation issues |
| `add_structure` | Add a source (with `input`) or target (with `output`) document from a schema or data file |
| `add_function`, `add_constant`, `add_component` | Library functions (or calls of user functions), constants, filter / if-else / value-map / sort / input parameter / output |
| `connect`, `disconnect`, `remove_component` | Edit connections (an input takes one connection; reconnecting replaces it) and components |
| `auto_map` | Name- and structure-based connections from a source to a target document |
| `validate_mapping`, `run_mapping` | Check for problems; run and return each target's output (optionally writing the files) |
| `generate_xslt` | XSLT 1.0 / 2.0 for XML-to-XML mappings |
| `sample_values` | Example values per path from a source's input file |
| `list_functions` | Search the function library |
| `import_mfd` | Convert a MapForce `.mfd` to `.mmap` |

Every editing tool loads the `.mmap`, applies the change, saves it atomically and reports what changed
(new component ids, port names, replaced connections).

`--session <file.mmap> [--base-dir <dir>] [--no-data]` limits the server to one mapping, as the desktop
app's AI assist uses it: the `mapping` argument is dropped, `create_mapping`, `import_mfd` and
`generate_xslt` are left out, `run_mapping` doesn't write outputs, relative paths resolve against
`--base-dir`, and `--no-data` also leaves out the tools that read input files.

Example prompt:

> Using mapster, create `contacts.mmap` that maps `fixtures/basic/company.xml` (schema
> `fixtures/basic/company.xsd`) to `fixtures/basic/contacts.xsd`, writing `out/contacts.xml`. One Contact per
> Person; FullName is First + " " + Last, Dept is the department name, Senior is true when Age > 40, and
> Total is the number of people. Validate it, run it and show me the output.

## How compatibility was established

See [`re/REA.md`](re/REA.md) and [`re/FINDINGS.md`](re/FINDINGS.md). In short: MapForce 2022's
executable was analyzed with [rea](https://github.com/morluto/rea) (artifact inventory, PE
resources, and native analysis with rea's Ghidra provider) (PE resources: menus, dialogs, string tables, embedded rule
files), its function-library descriptors and help were mined for signatures and behavior, and its
COM automation API was used to create `.mfd` files and run its built-in engine on Mapster's own
test fixtures. Those runs produce the golden outputs in `tests/conformance`. No Altova code or
assets are included in Mapster.
